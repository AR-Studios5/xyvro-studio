/**
 * @fileoverview Zira AI Core App (Live AI Voice Integration)
 * Fixed Modal Events & 20-Message Limit UI.
 */

document.addEventListener('DOMContentLoaded', function() {

  // --- 1. APPLE-STYLE TOAST NOTIFICATION SYSTEM ---
  function showToast(message, type) {
    var container = document.getElementById('toast-container');
    if (!container) return;

    var toast = document.createElement('div');
    toast.className = 'm-toast toast-' + (type || 'info');
    
    var icon = type === 'error' ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>' : 
               type === 'success' ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>' : 
               '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0ea5e9" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';

    toast.innerHTML = icon + '<span style="font-size: 13px; font-weight: 600; color: #0F172A; flex:1; overflow: hidden; text-overflow: ellipsis;">' + message + '</span>';
    container.appendChild(toast);
    
    setTimeout(function() {
      toast.classList.add('closing');
      setTimeout(function() { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 300);
    }, 4500);
  }

  // --- 2. LIVE SUPABASE CLIENT INITIALIZATION ---
  var SUPABASE_URL = "https://qqkdnxwnveeispvvhqdw.supabase.co";
  var SUPABASE_ANON_KEY = "sb_publishable_ECLFAKJP3G-LXe6dit9VTg_p2OssZ7k";
  var supabaseClient = null;

  if (window.supabase && typeof window.supabase.createClient === 'function') {
    supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
  } else {
    showToast("Network error: Could not load backend database.", "error");
  }

  // Robust Element Fetcher
  function getEl(id) { return document.getElementById(id); }

  var appWrapper = getEl('app-wrapper');
  var chatScreen = getEl('chat-screen');
  var authScreen = getEl('auth-screen');
  var dropdownMenu = getEl('dropdown-menu');
  var loadingOverlay = getEl('loading-overlay');
  
  var currentUser = null;
  var currentProfile = null;
  var isLimitReached = false;
  var hasRenderedPaywall = false;
  var authMode = "login";

  function loadLocalChatHistory() {
    var chatCanvas = getEl('chat-canvas');
    var typingIndicator = getEl('typing-indicator');
    if (!chatCanvas || !typingIndicator) return;

    var saved = localStorage.getItem('zira_chat_history');
    if (saved) {
      try {
        var messages = JSON.parse(saved);
        messages.forEach(function(msg) {
          var bubble = document.createElement('div');
          bubble.className = 'bubble ' + (msg.sender === 'user' ? 'bubble-out' : 'bubble-in');
          bubble.textContent = msg.text;
          chatCanvas.insertBefore(bubble, typingIndicator);
        });
        chatCanvas.scrollTo({ top: chatCanvas.scrollHeight, behavior: 'auto' });
      } catch(e) {}
    }
  }

  function appendToLocalChatHistory(sender, text) {
    var saved = localStorage.getItem('zira_chat_history');
    var messages = saved ? JSON.parse(saved) : [];
    messages.push({ sender: sender, text: text, timestamp: new Date().toISOString() });
    if (messages.length > 30) messages = messages.slice(-30);
    localStorage.setItem('zira_chat_history', JSON.stringify(messages));
  }

  // --- QUOTA & PAYWALL SYSTEM ---
  function lockChatInputUI() {
    isLimitReached = true;
    var inputNode = getEl('message-input');
    var wrapperNode = getEl('chat-input-wrapper');
    var sendBtn = getEl('send-msg-btn');
    var micBtn = getEl('voice-record-btn');

    if(inputNode) { inputNode.disabled = true; inputNode.blur(); inputNode.placeholder = "Daily limit reached."; }
    if(wrapperNode) {
        wrapperNode.classList.add('disabled-input');
        wrapperNode.style.cursor = 'pointer';
        wrapperNode.onclick = triggerPaywallExpansion;
    }
    if(sendBtn) { sendBtn.style.pointerEvents = 'none'; sendBtn.style.transform = 'scale(0.8)'; sendBtn.style.filter = 'grayscale(1)'; }
    if(micBtn) { micBtn.style.pointerEvents = 'none'; micBtn.style.opacity = '0.5'; }
    
    if (!hasRenderedPaywall) {
        setTimeout(renderInFeedPaywallCard, 800); 
    }
  }

  function renderInFeedPaywallCard() {
    if (hasRenderedPaywall) return;
    var card = document.createElement('div');
    card.className = 'infeed-paywall-card';
    card.style.marginTop = '24px'; // Keeps it cleanly at the bottom
    card.innerHTML = '<div style="position: absolute; top: -14px; left: 50%; transform: translateX(-50%) rotate(-6deg); background: var(--gold); color: #000; font-size: 16px; font-weight: 800; padding: 4px 16px; border-radius: 8px; border: 1.5px solid #000; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">₹1</div>' +
      '<div style="font-size: 18px; font-weight: 800; margin-top: 16px; margin-bottom: 14px; color: var(--text-dark);">continue talking</div>' +
      '<ul style="list-style: none; margin-bottom: 18px; text-align: left; display: inline-block; padding: 0;">' +
        '<li style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 8px; display: flex; align-items: center; gap: 8px;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:16px;height:16px;color:var(--accent-blue);"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg> unlimited messages</li>' +
        '<li style="font-size: 13px; font-weight: 600; color: var(--text-muted); margin-bottom: 8px; display: flex; align-items: center; gap: 8px;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:16px;height:16px;color:var(--accent-blue);"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg> unlimited calls with zira</li>' +
      '</ul>' +
      '<button type="button" class="btn-black pill shadow-hover" id="infeed-unlock-btn" style="width: 100%;">unlock with ₹1</button>';
    
    var chatCanvas = getEl('chat-canvas');
    var typingIndicator = getEl('typing-indicator');
    if (chatCanvas && typingIndicator) {
      chatCanvas.insertBefore(card, typingIndicator);
      chatCanvas.scrollTo({ top: chatCanvas.scrollHeight, behavior: 'smooth' });
      hasRenderedPaywall = true;
    }
    
    var btn = getEl('infeed-unlock-btn');
    if(btn) btn.onclick = triggerPaywallExpansion;
  }

  async function fetchUserProfile(userId) {
    if (!supabaseClient) return;
    var res = await supabaseClient.from('profiles').select('*').eq('id', userId).single();
    if (res.data) {
      currentProfile = res.data;
      if (currentProfile.daily_messages_sent >= 20 && !currentProfile.is_subscribed) {
          lockChatInputUI(); 
      }
    }
  }

  async function syncAuthState() {
    if (!supabaseClient) return;
    var sessionRes = await supabaseClient.auth.getSession();
    var session = sessionRes.data ? sessionRes.data.session : null;

    if (session && session.user) {
      currentUser = session.user;
      
      if (authScreen && chatScreen) {
        authScreen.classList.remove('active'); authScreen.classList.add('hidden');
        chatScreen.classList.remove('hidden'); chatScreen.classList.add('active');
      }
      loadLocalChatHistory();
      await fetchUserProfile(currentUser.id); 
    }
  }
  syncAuthState();

  // --- AUTH FLOW ---
  if(getEl('tab-login')) getEl('tab-login').onclick = function() {
    authMode = "login";
    getEl('tab-login').classList.add('active');
    getEl('tab-signup').classList.remove('active');
    getEl('mode-switcher-container').setAttribute('data-mode', 'login');
    getEl('name-field-group').classList.remove('expanded');
    getEl('login-email-btn').textContent = 'Log In';
  };

  if(getEl('tab-signup')) getEl('tab-signup').onclick = function() {
    authMode = "signup";
    getEl('tab-signup').classList.add('active');
    getEl('tab-login').classList.remove('active');
    getEl('mode-switcher-container').setAttribute('data-mode', 'signup');
    var nameGrp = getEl('name-field-group');
    nameGrp.classList.remove('hidden-collapse');
    void nameGrp.offsetWidth;
    nameGrp.classList.add('expanded');
    getEl('login-email-btn').textContent = 'Sign Up';
  };

  var passwordVisible = false;
  if(getEl('eye-toggle-btn')) getEl('eye-toggle-btn').onclick = function() {
    passwordVisible = !passwordVisible;
    getEl('password').type = passwordVisible ? 'text' : 'password';
  };

  if(getEl('login-email-btn')) getEl('login-email-btn').onclick = function() {
    var email = getEl('email').value;
    var pwd = getEl('password').value;
    if (!email || !pwd) { showToast("Please enter both email and password.", "error"); return; }
    getEl('compliance-modal').classList.remove('hidden');
  };

  if(getEl('confirm-compliance-btn')) getEl('confirm-compliance-btn').onclick = async function() {
    var ageCheck = getEl('age-check').checked;
    var tosCheck = getEl('tos-check').checked;
    if (!ageCheck || !tosCheck) {
      showToast("Please agree to the terms to continue.", "error");
      return;
    }
    getEl('compliance-modal').classList.add('hidden');
    
    var email = getEl('email').value;
    var password = getEl('password').value;
    var fullname = getEl('fullname').value;
    
    if (loadingOverlay) loadingOverlay.classList.remove('hidden');
    try {
      if (authMode === "signup") {
        var signUpRes = await supabaseClient.auth.signUp({
          email: email, password: password, options: { data: { full_name: fullname || 'Friend' } }
        });
        if (signUpRes.error) throw signUpRes.error;
        currentUser = signUpRes.data.user;
        showToast("Account created successfully! ✨", "success");
      } else {
        var signInRes = await supabaseClient.auth.signInWithPassword({ email: email, password: password });
        if (signInRes.error) throw signInRes.error;
        currentUser = signInRes.data.user;
        showToast("Welcome back!", "success");
      }
      
      await fetchUserProfile(currentUser.id);
      
      authScreen.classList.remove('active'); authScreen.classList.add('hidden');
      chatScreen.classList.remove('hidden'); chatScreen.classList.add('active');
      loadLocalChatHistory();
      
      if(!isLimitReached) {
          simulateIncomingMessage("Hii! So glad you're here ✨", null);
      }
    } catch (err) {
      showToast(err.message || "Authentication error occurred.", "error");
    } finally {
      if (loadingOverlay) loadingOverlay.classList.add('hidden');
    }
  };

  if(getEl('logout-btn')) getEl('logout-btn').onclick = async function() {
    if (supabaseClient) await supabaseClient.auth.signOut();
    currentUser = null; currentProfile = null;
    isLimitReached = false; hasRenderedPaywall = false;
    localStorage.removeItem('zira_chat_history');
    
    chatScreen.classList.remove('active'); chatScreen.classList.add('hidden');
    authScreen.classList.remove('hidden'); authScreen.classList.add('active');
    if(dropdownMenu) dropdownMenu.classList.add('hidden');
    
    getEl('chat-canvas').innerHTML = '<div class="greeting-wave">👋 you waved hi</div><div class="bubble bubble-in typing-bubble hidden" id="typing-indicator"><svg width="28" height="8" viewBox="0 0 36 12" fill="currentColor"><circle cx="6" cy="6" r="4" class="typing-dot dot-1" /><circle cx="18" cy="6" r="4" class="typing-dot dot-2" /><circle cx="30" cy="6" r="4" class="typing-dot dot-3" /></svg></div>';
    
    var inputNode = getEl('message-input');
    if(inputNode) { inputNode.disabled = false; inputNode.placeholder = "type your message.."; }
    getEl('chat-input-wrapper').classList.remove('disabled-input');
    getEl('chat-input-wrapper').onclick = null;
    getEl('send-msg-btn').style.pointerEvents = 'all';
    getEl('send-msg-btn').style.filter = 'none';
    getEl('voice-record-btn').style.pointerEvents = 'all';
    getEl('voice-record-btn').style.opacity = '1';
    
    showToast("Logged out safely.", "info");
  };


  // --- ROBUST MENU & MODAL BINDINGS ---
  if(getEl('dropdown-toggle-btn')) getEl('dropdown-toggle-btn').onclick = function(e) {
    e.stopPropagation();
    if(dropdownMenu) dropdownMenu.classList.toggle('hidden');
  };

  if(getEl('header-voice-btn')) getEl('header-voice-btn').onclick = function(e) {
    e.stopPropagation();
    if(getEl('call-gate-modal')) getEl('call-gate-modal').classList.remove('hidden');
  };

  if(getEl('gate-notnow-btn')) getEl('gate-notnow-btn').onclick = function(e) {
    e.stopPropagation();
    if(getEl('call-gate-modal')) getEl('call-gate-modal').classList.add('hidden');
  };

  document.querySelectorAll('.modal-trigger').forEach(function(el) {
    el.onclick = function(e) {
      e.stopPropagation();
      var targetId = this.getAttribute('data-target');
      if(getEl(targetId)) getEl(targetId).classList.remove('hidden');
      if(dropdownMenu) dropdownMenu.classList.add('hidden');
    };
  });

  if(getEl('close-rate-btn')) getEl('close-rate-btn').onclick = function(e) {
      e.stopPropagation(); getEl('rate-modal').classList.add('hidden'); 
  };
  if(getEl('close-support-btn')) getEl('close-support-btn').onclick = function(e) { 
      e.stopPropagation(); getEl('support-modal').classList.add('hidden'); 
  };

  document.addEventListener('click', function(e) {
    if (dropdownMenu && !dropdownMenu.classList.contains('hidden') && !dropdownMenu.contains(e.target) && e.target.id !== 'dropdown-toggle-btn') {
      dropdownMenu.classList.add('hidden');
    }
  });

  if(getEl('clear-chat-btn')) getEl('clear-chat-btn').onclick = function() {
    if(dropdownMenu) dropdownMenu.classList.add('hidden');
    localStorage.removeItem('zira_chat_history');
    getEl('chat-canvas').innerHTML = '<div class="greeting-wave">👋 you waved hi</div><div class="bubble bubble-in typing-bubble hidden" id="typing-indicator"><svg width="28" height="8" viewBox="0 0 36 12" fill="currentColor"><circle cx="6" cy="6" r="4" class="typing-dot dot-1" /><circle cx="18" cy="6" r="4" class="typing-dot dot-2" /><circle cx="30" cy="6" r="4" class="typing-dot dot-3" /></svg></div>';
    hasRenderedPaywall = false;
    showToast("Chat cleared.", "info");
    
    if (!isLimitReached) {
      setTimeout(function() { simulateIncomingMessage("Hii! So glad you're here ✨"); }, 200);
    } else {
      setTimeout(function() { renderInFeedPaywallCard(); }, 400);
    }
  };


  // --- AUDIO ENGINE ---
  var mediaRecorder = null;
  var audioChunks = [];
  var audioContext = null;
  var analyser = null;
  var silenceTimer = null;
  var isMicRecording = false;

  async function startRecording(onSilenceCallback) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder = new MediaRecorder(stream);
      audioChunks = [];

      mediaRecorder.ondataavailable = function(e) { if (e.data.size > 0) audioChunks.push(e.data); };

      if (onSilenceCallback) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        var source = audioContext.createMediaStreamSource(stream);
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 512;
        source.connect(analyser);
        var bufferLength = analyser.frequencyBinCount;
        var dataArray = new Uint8Array(bufferLength);

        function checkSilence() {
          if (!isMicRecording) return;
          analyser.getByteFrequencyData(dataArray);
          var sum = 0;
          for(var i = 0; i < bufferLength; i++) sum += dataArray[i];
          var average = sum / bufferLength;

          if (average < 15) { 
            if (!silenceTimer) {
              silenceTimer = setTimeout(function() { if (isMicRecording) onSilenceCallback(); }, 1500); 
            }
          } else {
            if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
          }
          requestAnimationFrame(checkSilence);
        }
        checkSilence();
      }

      mediaRecorder.start();
      isMicRecording = true;
    } catch(err) {
      showToast("Microphone access denied. Please allow mic permissions.", "error");
    }
  }

  function stopRecording(callback) {
    if (!mediaRecorder || mediaRecorder.state === 'inactive') return;
    isMicRecording = false;
    if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
    
    mediaRecorder.onstop = function() {
      var mimeType = mediaRecorder.mimeType || 'audio/webm';
      var audioBlob = new Blob(audioChunks, { type: mimeType });
      var reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = function() {
        var base64data = reader.result.split(',')[1];
        callback(base64data, mimeType);
      }
      mediaRecorder.stream.getTracks().forEach(function(track) { track.stop(); });
      if(audioContext) { audioContext.close(); audioContext = null; }
    };
    mediaRecorder.stop();
  }

  function playBase64Audio(base64) {
    var audio = new Audio("data:audio/mp3;base64," + base64);
    audio.play().catch(function(e){ showToast("Could not play audio snippet.", "error"); });
  }

  async function callZiraAI(text, audioBase64, replyWithAudio, context, mimeType) {
    if (!supabaseClient) return { error: "Supabase client not initialized." };
    try {
      const res = await supabaseClient.functions.invoke('chat', {
        body: { text: text, audioBase64: audioBase64, replyWithAudio: replyWithAudio, context: context, mimeType: mimeType }
      });
      
      if (res.error) { return { error: "Zira's brain connection dropped." }; }
      if (res.data && res.data.error) { return { error: res.data.error }; }
      return res.data;
    } catch (err) {
      return { error: "Failed to reach backend: " + err.message };
    }
  }

  // --- GENERAL CHAT MESSAGING ---
  async function sendMessage() {
    if (isLimitReached) { lockChatInputUI(); return; }
    var messageInputNode = getEl('message-input');
    var voiceReviewUi = getEl('voice-review-ui');
    var isVoiceNote = voiceReviewUi && !voiceReviewUi.classList.contains('hidden');
    var text = messageInputNode ? messageInputNode.value.trim() : "";
    
    if (!isVoiceNote && !text) return;
    
    if (currentUser && supabaseClient) {
      var rpcRes = await supabaseClient.rpc('check_and_increment_quota', { p_user_id: currentUser.id });
      if (rpcRes.data) {
        if (!rpcRes.data.allowed) { lockChatInputUI(); return; }
        if (rpcRes.data.limit_reached) lockChatInputUI();
      }
    }

    var chatCanvas = getEl('chat-canvas');
    var typingIndicator = getEl('typing-indicator');

    if (isVoiceNote) {
      var outBubble = document.createElement('div');
      outBubble.className = 'bubble bubble-out voice-note';
      outBubble.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg><div class="fake-waveform"><span></span><span></span><span></span><span></span><span></span><span></span></div><span>Sent</span>';
      
      voiceReviewUi.classList.add('hidden');
      getEl('voice-record-btn').classList.remove('collapsed-width');
      getEl('chat-input-wrapper').classList.remove('hidden');

      chatCanvas.insertBefore(outBubble, typingIndicator);
      chatCanvas.scrollTo({ top: chatCanvas.scrollHeight, behavior: 'smooth' });

      stopRecording(async function(base64Audio, mimeType) {
         if (typingIndicator) typingIndicator.classList.remove('hidden');
         var response = await callZiraAI("", base64Audio, true, "chat", mimeType);
         if (typingIndicator) typingIndicator.classList.add('hidden');
         
         if (response && response.error) { showToast(response.error, "error"); return; }
         if (response && response.text) { simulateIncomingMessage(response.text, response.audioBase64); }
      });
    } else {
      var outBubble = document.createElement('div');
      outBubble.className = 'bubble bubble-out';
      outBubble.textContent = text;
      if (messageInputNode) messageInputNode.value = '';

      chatCanvas.insertBefore(outBubble, typingIndicator);
      chatCanvas.scrollTo({ top: chatCanvas.scrollHeight, behavior: 'smooth' });
      appendToLocalChatHistory('user', text);

      if (typingIndicator) typingIndicator.classList.remove('hidden');
      var response = await callZiraAI(text, null, false, "chat", null);
      if (typingIndicator) typingIndicator.classList.add('hidden');
      
      if (response && response.error) { showToast(response.error, "error"); return; }
      if (response && response.text) { simulateIncomingMessage(response.text, response.audioBase64); }
    }
  }

  function simulateIncomingMessage(text, audioBase64) {
    var chatCanvas = getEl('chat-canvas');
    var typingIndicator = getEl('typing-indicator');
    if (!chatCanvas || !typingIndicator) return;
    
    var inBubble = document.createElement('div');
    if (audioBase64) {
      inBubble.className = 'bubble bubble-in voice-note';
      var row = document.createElement('div');
      row.className = 'voice-row';
      row.innerHTML = '<button type="button" class="play-audio-btn"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg></button><div class="fake-waveform"><span></span><span></span><span></span><span></span><span></span><span></span></div>';
      var playBtn = row.querySelector('.play-audio-btn');
      playBtn.onclick = function() { playBase64Audio(audioBase64); };
      inBubble.appendChild(row);
      var textEl = document.createElement('div');
      textEl.style.marginTop = '8px'; textEl.style.fontSize = '13px'; textEl.style.color = 'var(--text-muted)'; textEl.textContent = text;
      inBubble.appendChild(textEl);
    } else {
      inBubble.className = 'bubble bubble-in';
      inBubble.textContent = text;
    }
    
    chatCanvas.insertBefore(inBubble, typingIndicator);
    chatCanvas.scrollTo({ top: chatCanvas.scrollHeight, behavior: 'smooth' });
    appendToLocalChatHistory('zira', text);
    if (audioBase64) playBase64Audio(audioBase64);
  }

  // --- NAVIGATION & UTILITIES ---
  function triggerPaywallExpansion() {
    if (dropdownMenu) dropdownMenu.classList.add('hidden');
    var callGate = getEl('call-gate-modal');
    if (callGate) callGate.classList.add('hidden');
    if (loadingOverlay) loadingOverlay.classList.remove('hidden');
    if (appWrapper) appWrapper.classList.add('animating-snake');

    setTimeout(function() {
      if (appWrapper) { appWrapper.classList.remove('animating-snake'); appWrapper.classList.add('solid-border'); }
      setTimeout(function() {
        if (appWrapper) appWrapper.classList.add('expanded-mode');
        var paywallScreen = getEl('paywall-screen');
        if (chatScreen) { chatScreen.classList.remove('active'); chatScreen.classList.add('hidden'); }
        if (paywallScreen) { paywallScreen.classList.remove('hidden'); paywallScreen.classList.add('active'); }
        setTimeout(function() {
          if (loadingOverlay) loadingOverlay.classList.add('hidden');
          if (appWrapper) appWrapper.classList.remove('solid-border');
        }, 350);
      }, 300);
    }, 1500);
  }

  if(getEl('gate-unlock-btn')) getEl('gate-unlock-btn').onclick = triggerPaywallExpansion;
  if(getEl('open-paywall-btn')) getEl('open-paywall-btn').onclick = triggerPaywallExpansion;

  if(getEl('close-paywall-btn')) getEl('close-paywall-btn').onclick = function() {
    var paywallScreen = getEl('paywall-screen');
    if (paywallScreen) { paywallScreen.classList.remove('active'); paywallScreen.classList.add('hidden'); }
    if (appWrapper) appWrapper.classList.remove('expanded-mode');
    if (chatScreen) { chatScreen.classList.remove('hidden'); chatScreen.classList.add('active'); }
  };

  var reviewTrack = getEl('review-track');
  var reviewContainer = getEl('review-carousel');
  var autoScrollInterval;

  if (reviewTrack && reviewContainer) {
    var fakeReviews = [
      { t: "Best app ever, actually cured my boredom", a: "aman_99" },
      { t: "Zira is literally my bestie 😂", a: "priyanka.s" },
      { t: "Way better than Character AI.", a: "rohit_gaming" }
    ];

    fakeReviews.forEach(function(r) {
      var card = document.createElement('div');
      card.className = 'review-card';
      card.innerHTML = '<p class="review-text">"' + r.t + '"</p><p class="review-author">' + r.a + '</p>';
      reviewTrack.appendChild(card);
    });

    function startScroll() {
      autoScrollInterval = setInterval(function() {
        reviewTrack.style.transition = 'transform 0.6s cubic-bezier(0.32, 0.72, 0, 1)';
        reviewTrack.style.transform = 'translateX(-100%)';
        setTimeout(function() {
          reviewTrack.style.transition = 'none';
          reviewTrack.appendChild(reviewTrack.firstElementChild);
          reviewTrack.style.transform = 'translateX(0)';
        }, 600);
      }, 3000);
    }
    startScroll();
    reviewContainer.addEventListener('pointerdown', function() { clearInterval(autoScrollInterval); });
    reviewContainer.addEventListener('pointerup', function() { clearInterval(autoScrollInterval); startScroll(); });
    reviewContainer.addEventListener('pointerleave', function() { clearInterval(autoScrollInterval); startScroll(); });
  }

  function openGamesHub() {
    if (dropdownMenu) dropdownMenu.classList.add('hidden');
    if (appWrapper) appWrapper.classList.add('expanded-mode');
    var gamesScreen = getEl('games-screen');
    if (chatScreen) { chatScreen.classList.remove('active'); chatScreen.classList.add('hidden'); }
    if (gamesScreen) { gamesScreen.classList.remove('hidden'); gamesScreen.classList.add('active'); }
    var grid = getEl('games-selector-grid');
    var arena = getEl('chess-arena-view');
    if(grid) grid.classList.remove('hidden');
    if(arena) arena.classList.add('hidden');
  }

  if(getEl('header-games-btn')) getEl('header-games-btn').onclick = openGamesHub;
  if(getEl('menu-games-btn')) getEl('menu-games-btn').onclick = openGamesHub;

  if(getEl('close-games-btn')) getEl('close-games-btn').onclick = function() {
    var gamesScreen = getEl('games-screen');
    if (gamesScreen) { gamesScreen.classList.remove('active'); gamesScreen.classList.add('hidden'); }
    if (appWrapper) appWrapper.classList.remove('expanded-mode');
    if (chatScreen) { chatScreen.classList.remove('hidden'); chatScreen.classList.add('active'); }
  };

  if(getEl('card-play-chess')) getEl('card-play-chess').onclick = function() {
    getEl('games-selector-grid').classList.add('hidden');
    getEl('chess-arena-view').classList.remove('hidden');
    initDummyChess();
  };

  if(getEl('chess-restart-btn')) getEl('chess-restart-btn').onclick = initDummyChess;

  var selectedChessSquare = null;
  var currentBoard = [];
  function initDummyChess() {
    currentBoard = [['♜','♞','♝','♛','♚','♝','♞','♜'],['♟','♟','♟','♟','♟','♟','♟','♟'],['','','','','','','',''],['','','','','','','',''],['','','','','','','',''],['','','','','','','',''],['♙','♙','♙','♙','♙','♙','♙','♙'],['♖','♘','♗','♕','♔','♗','♘','♖']];
    selectedChessSquare = null;
    getEl('mira-chess-speech').textContent = '"Chal safed teri hai! Soch samajh ke chalna 😏"';
    getEl('chess-turn-status').textContent = "Your turn (White)";
    renderDummyBoard();
  }

  function renderDummyBoard() {
    var chessboardGrid = getEl('chessboard-grid');
    if (!chessboardGrid) return;
    chessboardGrid.innerHTML = '';
    for (var r = 0; r < 8; r++) {
      for (var c = 0; c < 8; c++) {
        (function(row, col) {
          var squareEl = document.createElement('div');
          squareEl.className = 'chess-square ' + ((row + col) % 2 === 0 ? 'light' : 'dark');
          var piece = currentBoard[row][col];
          if (piece) {
            squareEl.textContent = piece;
            squareEl.style.color = '♖♘♗♕♔♙'.indexOf(piece) !== -1 ? '#FFFFFF' : '#0F172A';
            squareEl.style.textShadow = '♖♘♗♕♔♙'.indexOf(piece) !== -1 ? '0 2px 4px rgba(0,0,0,0.6)' : 'none';
          }
          if (selectedChessSquare && selectedChessSquare.r === row && selectedChessSquare.c === col) squareEl.classList.add('selected');
          
          squareEl.onclick = function() {
            if (!selectedChessSquare) {
              if (piece && '♖♘♗♕♔♙'.indexOf(piece) !== -1) { selectedChessSquare = { r: row, c: col }; renderDummyBoard(); }
            } else {
              currentBoard[row][col] = currentBoard[selectedChessSquare.r][selectedChessSquare.c];
              currentBoard[selectedChessSquare.r][selectedChessSquare.c] = '';
              selectedChessSquare = null;
              renderDummyBoard();
            }
          };
          chessboardGrid.appendChild(squareEl);
        })(r, c);
      }
    }
  }

  function simulateRandomChessMove() {
     currentBoard[2][0] = currentBoard[1][0]; 
     currentBoard[1][0] = '';
     renderDummyBoard();
  }

  // --- CHESS MIC INTEGRATION ---
  var chessMicBtn = getEl('chess-mic-btn');
  if(chessMicBtn) chessMicBtn.onclick = function() {
    if (isMicRecording) {
      processChessAudio();
    } else {
      chessMicBtn.classList.add('recording');
      chessMicBtn.innerHTML = 'Listening...';
      startRecording(function() { processChessAudio(); });
    }
  };

  function processChessAudio() {
    if(!isMicRecording) return;
    var chessMicBtn = getEl('chess-mic-btn');
    var speech = getEl('mira-chess-speech');
    var status = getEl('chess-turn-status');

    chessMicBtn.classList.remove('recording');
    chessMicBtn.innerHTML = 'Thinking...';
    if (status) status.textContent = "Zira is thinking...";
    
    stopRecording(async function(base64Audio, mimeType) {
      var response = await callZiraAI("", base64Audio, true, "chess", mimeType);
      chessMicBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px;"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="22"></line></svg> Speak';

      if (response && response.error) {
        showToast(response.error, "error");
        if (status) status.textContent = "Your turn (White)";
        return;
      }

      if (response && response.text) {
        if(speech) speech.textContent = '"' + response.text + '"';
        if(response.audioBase64) playBase64Audio(response.audioBase64);
        if (status) status.textContent = "Your turn (White)";
        simulateRandomChessMove();
      } else {
        if(speech) speech.textContent = '"Kya bola? Sunai nahi diya thik se."';
        if (status) status.textContent = "Your turn (White)";
      }
    });
  }

  var voiceRecordBtn = getEl('voice-record-btn');
  var voiceRecordingUi = getEl('voice-recording-ui');
  var voiceReviewUi = getEl('voice-review-ui');
  var chatInputWrapper = getEl('chat-input-wrapper');
  var recordTimer = null;
  var recordSeconds = 0;

  if(voiceRecordBtn) voiceRecordBtn.onclick = function() {
    if(isLimitReached) return;
    voiceRecordBtn.classList.add('collapsed-width');
    chatInputWrapper.classList.add('hidden');
    voiceRecordingUi.classList.remove('hidden');
    
    recordSeconds = 0;
    var timeSpan = voiceRecordingUi.querySelector('.recording-time');
    if (timeSpan) timeSpan.textContent = '0:00';
    
    recordTimer = setInterval(function() {
      recordSeconds++;
      var mins = Math.floor(recordSeconds / 60);
      var secs = recordSeconds % 60;
      if (timeSpan) timeSpan.textContent = mins + ':' + (secs < 10 ? '0' : '') + secs;
    }, 1000);

    startRecording(null); 
  };

  if(getEl('stop-record-btn')) getEl('stop-record-btn').onclick = function() {
    clearInterval(recordTimer);
    voiceRecordingUi.classList.add('hidden');
    voiceReviewUi.classList.remove('hidden');
  };

  if(getEl('delete-voice-btn')) getEl('delete-voice-btn').onclick = function() {
    voiceReviewUi.classList.add('hidden');
    voiceRecordBtn.classList.remove('collapsed-width');
    chatInputWrapper.classList.remove('hidden');
    stopRecording(function(){}); 
  };

  var messageInputNode = getEl('message-input');
  if (messageInputNode) {
    messageInputNode.addEventListener('keypress', function(e) { if (e.key === 'Enter') sendMessage(); });
  }
  if(getEl('send-msg-btn')) getEl('send-msg-btn').onclick = sendMessage;

  // --- STORIES LOGIC ---
  var storyInterval = null;
  var storyProgressVal = 0;
  var isStoryPaused = false;
  var storyRepliesSheet = getEl('story-replies-sheet');
  var storyReplyInput = getEl('story-reply-input');
  var storyReplyArea = document.querySelector('.story-reply-area');

  function startStoryProgress() {
    storyProgressVal = 0;
    isStoryPaused = false;
    var fill = getEl('story-fill');
    if (fill) fill.style.width = '0%';
    clearInterval(storyInterval);

    storyInterval = setInterval(function() {
      if (!isStoryPaused) {
        storyProgressVal += 0.5;
        if (fill) fill.style.width = storyProgressVal + '%';
        if (storyProgressVal >= 100) {
          clearInterval(storyInterval);
          var closeBtn = getEl('close-story-btn');
          if(closeBtn) closeBtn.click();
        }
      }
    }, 30);
  }

  if(getEl('avatar-trigger')) getEl('avatar-trigger').onclick = function() {
    if (appWrapper) appWrapper.classList.add('expanded-mode');
    if (chatScreen) { chatScreen.classList.remove('active'); chatScreen.classList.add('hidden'); }
    var storyScreen = getEl('story-screen');
    if (storyScreen) { storyScreen.classList.remove('hidden'); storyScreen.classList.add('active'); }
    startStoryProgress();
  };

  if(getEl('close-story-btn')) getEl('close-story-btn').onclick = function() {
    clearInterval(storyInterval);
    if(storyRepliesSheet) storyRepliesSheet.classList.remove('sheet-active');
    if(storyReplyArea) storyReplyArea.classList.remove('slid-down');
    var storyScreen = getEl('story-screen');
    if (storyScreen) { storyScreen.classList.remove('active'); storyScreen.classList.add('hidden'); }
    if (appWrapper) appWrapper.classList.remove('expanded-mode');
    if (chatScreen) { chatScreen.classList.remove('hidden'); chatScreen.classList.add('active'); }
  };

  if (storyReplyInput) {
    storyReplyInput.onfocus = function() { isStoryPaused = true; };
    storyReplyInput.oninput = function() { isStoryPaused = true; };
    storyReplyInput.onblur = function() { 
      if (storyRepliesSheet && !storyRepliesSheet.classList.contains('sheet-active')) { isStoryPaused = false; }
    };
  }

  if(getEl('open-story-replies-btn')) getEl('open-story-replies-btn').onclick = function() {
    isStoryPaused = true;
    if(storyReplyArea) storyReplyArea.classList.add('slid-down');
    if(storyRepliesSheet) storyRepliesSheet.classList.add('sheet-active');
  };

  function dismissRepliesSheet() {
    if(storyRepliesSheet) storyRepliesSheet.classList.remove('sheet-active');
    if(storyReplyArea) storyReplyArea.classList.remove('slid-down');
    isStoryPaused = false;
  }

  if(getEl('close-sheet-btn')) getEl('close-sheet-btn').onclick = dismissRepliesSheet;
  
  var startY = 0;
  var closeSheetHandle = getEl('close-sheet-handle');
  if (closeSheetHandle) {
    closeSheetHandle.ontouchstart = function(e) { startY = e.touches[0].clientY; };
    closeSheetHandle.ontouchmove = function(e) {
      var deltaY = e.touches[0].clientY - startY;
      if (deltaY > 50) dismissRepliesSheet();
    };
  }

  if(getEl('story-reply-btn')) getEl('story-reply-btn').onclick = function() {
    if (!storyReplyInput) return;
    var replyText = storyReplyInput.value.trim();
    if (!replyText) return;

    var userReplyItem = document.createElement('div');
    userReplyItem.className = 'reply-item';
    userReplyItem.innerHTML = '<div class="reply-avatar" style="background:#DCFCE7; color:#16A34A;">You</div><div class="reply-content"><strong>You</strong><p>' + replyText + '</p><span class="reply-time">Just now</span></div>';
    
    var list = getEl('story-replies-list');
    if(list) list.prepend(userReplyItem);

    var countEl = getEl('story-replies-count');
    if (countEl) countEl.textContent = (parseInt(countEl.textContent || '3', 10) + 1).toString();

    storyReplyInput.value = '';
    storyReplyInput.placeholder = 'Sent! ✨';
    setTimeout(function() { storyReplyInput.placeholder = 'reply to Zira...'; }, 1500);
    
    if(storyRepliesSheet && storyRepliesSheet.classList.contains('sheet-active')){
       setTimeout(dismissRepliesSheet, 800);
    } else {
       isStoryPaused = false;
    }
  };

});
