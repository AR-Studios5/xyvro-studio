import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-_wkVunZg.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "fixed inset-0 bg-[#F3EDE4]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "sr-only",
			children: "Zira, your everyday companion from Vellox Labs."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			title: "Zira",
			src: "/zira-app/index.html",
			allow: "microphone; clipboard-write",
			className: "absolute inset-0 h-full w-full border-0 bg-[#F3EDE4]"
		})]
	});
}
//#endregion
export { Home as component };
