(function () {
  function hideSplash() {
    if (typeof document === "undefined") return;
    var el = document.getElementById("splash");
    if (!el || el.classList.contains("hidden")) return;
    el.classList.add("hidden");
    el.setAttribute("aria-hidden", "true");
  }

  if (typeof window !== "undefined") {
    window.setTimeout(hideSplash, 1000);
  }

  var START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  var SEED_REPLIES = [
    { name: "aarav", body: "yeh cafe kahan hai, itna shaant", time: "1h" },
    { name: "priya", body: "Zira you never take me with you", time: "45m" },
    { name: "rohit", body: "light is actually unfair", time: "20m" }
  ];
  var KEY = "zira-state-v1";

  function alg(i) {
    return "abcdefgh"[i % 8] + String(((i / 8) | 0) + 1);
  }

  function fromAlg(s) {
    if (!s || s === "-") return -1;
    var f = s.charCodeAt(0) - 97;
    var r = s.charCodeAt(1) - 49;
    if (f < 0 || f > 7 || r < 0 || r > 7) return -1;
    return r * 8 + f;
  }

  function parseFen(fen) {
    var parts = fen.split(" ");
    var ranks = parts[0].split("/");
    var board = [];
    var i;
    for (i = 0; i < 64; i++) board.push("");
    ranks.forEach(function (rank, ri) {
      var file = 0;
      for (var c = 0; c < rank.length; c++) {
        var ch = rank.charAt(c);
        if (ch >= "1" && ch <= "8") file += Number(ch);
        else {
          board[(7 - ri) * 8 + file] = ch;
          file++;
        }
      }
    });
    var castle = 0;
    var cs = parts[2] || "-";
    if (cs.indexOf("K") >= 0) castle |= 1;
    if (cs.indexOf("Q") >= 0) castle |= 2;
    if (cs.indexOf("k") >= 0) castle |= 4;
    if (cs.indexOf("q") >= 0) castle |= 8;
    return {
      board: board,
      turn: parts[1] === "b" ? "b" : "w",
      castle: castle,
      ep: fromAlg(parts[3] || "-"),
      full: Number(parts[5] || 1) || 1
    };
  }

  function toFen(state) {
    var rows = [];
    for (var r = 7; r >= 0; r--) {
      var row = "";
      var empty = 0;
      for (var f = 0; f < 8; f++) {
        var p = state.board[r * 8 + f];
        if (!p) empty++;
        else {
          if (empty) {
            row += empty;
            empty = 0;
          }
          row += p;
        }
      }
      if (empty) row += empty;
      rows.push(row);
    }
    var c = "";
    if (state.castle & 1) c += "K";
    if (state.castle & 2) c += "Q";
    if (state.castle & 4) c += "k";
    if (state.castle & 8) c += "q";
    if (!c) c = "-";
    return rows.join("/") + " " + state.turn + " " + c + " " + (state.ep >= 0 ? alg(state.ep) : "-") + " 0 " + state.full;
  }

  function whitePiece(p) {
    return !!(p && p === p.toUpperCase());
  }

  function side(p, turn) {
    return turn === "w" ? whitePiece(p) : p && !whitePiece(p);
  }

  function onBoard(f, r) {
    return f >= 0 && f < 8 && r >= 0 && r < 8;
  }

  function isAttacked(board, square, byWhite) {
    var file = square % 8;
    var rank = (square / 8) | 0;
    var pawn = byWhite ? "P" : "p";
    var pr = byWhite ? -1 : 1;
    var df;
    for (df = -1; df <= 1; df += 2) {
      var f = file + df;
      var r = rank + pr;
      if (onBoard(f, r) && board[r * 8 + f] === pawn) return true;
    }
    var knight = byWhite ? "N" : "n";
    var jumps = [
      [1, 2],
      [2, 1],
      [-1, 2],
      [-2, 1],
      [1, -2],
      [2, -1],
      [-1, -2],
      [-2, -1]
    ];
    var j;
    for (j = 0; j < jumps.length; j++) {
      f = file + jumps[j][0];
      r = rank + jumps[j][1];
      if (onBoard(f, r) && board[r * 8 + f] === knight) return true;
    }
    var king = byWhite ? "K" : "k";
    for (var dr = -1; dr <= 1; dr++) {
      for (df = -1; df <= 1; df++) {
        if (!dr && !df) continue;
        f = file + df;
        r = rank + dr;
        if (onBoard(f, r) && board[r * 8 + f] === king) return true;
      }
    }
    function ray(dirs, a, b) {
      for (var d = 0; d < dirs.length; d++) {
        f = file + dirs[d][0];
        r = rank + dirs[d][1];
        while (onBoard(f, r)) {
          var p = board[r * 8 + f];
          if (p) {
            if (p === a || p === b) return true;
            break;
          }
          f += dirs[d][0];
          r += dirs[d][1];
        }
      }
      return false;
    }
    var queen = byWhite ? "Q" : "q";
    if (
      ray(
        [
          [1, 1],
          [1, -1],
          [-1, 1],
          [-1, -1]
        ],
        byWhite ? "B" : "b",
        queen
      )
    )
      return true;
    if (
      ray(
        [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1]
        ],
        byWhite ? "R" : "r",
        queen
      )
    )
      return true;
    return false;
  }

  function kingSquare(board, turn) {
    var want = turn === "w" ? "K" : "k";
    for (var i = 0; i < 64; i++) if (board[i] === want) return i;
    return -1;
  }

  function inCheck(state, turn) {
    var sq = kingSquare(state.board, turn);
    if (sq < 0) return true;
    return isAttacked(state.board, sq, turn !== "w");
  }

  function stampCastle(castle, from, to) {
    if (from === 4 || to === 4) castle &= ~3;
    if (from === 60 || to === 60) castle &= ~12;
    if (from === 0 || to === 0) castle &= ~2;
    if (from === 7 || to === 7) castle &= ~1;
    if (from === 56 || to === 56) castle &= ~8;
    if (from === 63 || to === 63) castle &= ~4;
    return castle;
  }

  function apply(state, move) {
    var board = state.board.slice();
    var piece = board[move.from];
    board[move.from] = "";
    if (move.ep) board[move.to + (state.turn === "w" ? -8 : 8)] = "";
    if (move.promo) piece = state.turn === "w" ? "Q" : "q";
    board[move.to] = piece;
    if (move.castle === "K") {
      board[7] = "";
      board[5] = "R";
    } else if (move.castle === "Q") {
      board[0] = "";
      board[3] = "R";
    } else if (move.castle === "k") {
      board[63] = "";
      board[61] = "r";
    } else if (move.castle === "q") {
      board[56] = "";
      board[59] = "r";
    }
    var ep = -1;
    if ((piece === "P" || piece === "p") && Math.abs(move.to - move.from) === 16) ep = (move.from + move.to) / 2;
    return {
      board: board,
      turn: state.turn === "w" ? "b" : "w",
      castle: stampCastle(state.castle, move.from, move.to),
      ep: ep,
      full: state.full + (state.turn === "b" ? 1 : 0)
    };
  }

  function pseudo(state, from) {
    var board = state.board;
    var piece = board[from];
    var moves = [];
    var file = from % 8;
    var rank = (from / 8) | 0;
    function add(to, extra) {
      if (to < 0 || to > 63) return;
      var target = board[to];
      if (target && whitePiece(target) === whitePiece(piece)) return;
      var move = { from: from, to: to };
      if (extra) {
        if (extra.ep) move.ep = true;
        if (extra.promo) move.promo = true;
        if (extra.castle) move.castle = extra.castle;
      }
      moves.push(move);
    }
    function slide(dirs) {
      for (var d = 0; d < dirs.length; d++) {
        var f = file + dirs[d][0];
        var r = rank + dirs[d][1];
        while (onBoard(f, r)) {
          var to = r * 8 + f;
          if (!board[to]) add(to);
          else {
            add(to);
            break;
          }
          f += dirs[d][0];
          r += dirs[d][1];
        }
      }
    }
    if (piece === "P" || piece === "p") {
      var dir = piece === "P" ? 8 : -8;
      var start = piece === "P" ? 1 : 6;
      var last = piece === "P" ? 7 : 0;
      var one = from + dir;
      if (one >= 0 && one < 64 && !board[one]) {
        add(one, ((one / 8) | 0) === last ? { promo: true } : null);
        if (rank === start) {
          var two = from + dir * 2;
          if (!board[two]) add(two);
        }
      }
      for (var cap = -1; cap <= 1; cap += 2) {
        var tf = file + cap;
        var tr = rank + (piece === "P" ? 1 : -1);
        if (!onBoard(tf, tr)) continue;
        var to = tr * 8 + tf;
        var promo = tr === last ? { promo: true } : null;
        if (board[to] && whitePiece(board[to]) !== whitePiece(piece)) add(to, promo);
        if (to === state.ep) add(to, { ep: true, promo: !!(promo && promo.promo) });
      }
      return moves;
    }
    if (piece === "N" || piece === "n") {
      var jumps = [
        [1, 2],
        [2, 1],
        [-1, 2],
        [-2, 1],
        [1, -2],
        [2, -1],
        [-1, -2],
        [-2, -1]
      ];
      for (var j = 0; j < jumps.length; j++) {
        var f2 = file + jumps[j][0];
        var r2 = rank + jumps[j][1];
        if (onBoard(f2, r2)) add(r2 * 8 + f2);
      }
      return moves;
    }
    if (piece === "B" || piece === "b") {
      slide([
        [1, 1],
        [1, -1],
        [-1, 1],
        [-1, -1]
      ]);
      return moves;
    }
    if (piece === "R" || piece === "r") {
      slide([
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1]
      ]);
      return moves;
    }
    if (piece === "Q" || piece === "q") {
      slide([
        [1, 1],
        [1, -1],
        [-1, 1],
        [-1, -1],
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1]
      ]);
      return moves;
    }
    if (piece === "K" || piece === "k") {
      for (var dr = -1; dr <= 1; dr++) {
        for (var df = -1; df <= 1; df++) {
          if (!dr && !df) continue;
          var f3 = file + df;
          var r3 = rank + dr;
          if (onBoard(f3, r3)) add(r3 * 8 + f3);
        }
      }
      var byBlack = piece === "K";
      if (piece === "K" && state.castle & 1 && !board[5] && !board[6] && board[7] === "R") {
        if (!isAttacked(board, 4, false) && !isAttacked(board, 5, false) && !isAttacked(board, 6, false))
          moves.push({ from: 4, to: 6, castle: "K" });
      }
      if (piece === "K" && state.castle & 2 && !board[1] && !board[2] && !board[3] && board[0] === "R") {
        if (!isAttacked(board, 4, false) && !isAttacked(board, 3, false) && !isAttacked(board, 2, false))
          moves.push({ from: 4, to: 2, castle: "Q" });
      }
      if (piece === "k" && state.castle & 4 && !board[61] && !board[62] && board[63] === "r") {
        if (!isAttacked(board, 60, true) && !isAttacked(board, 61, true) && !isAttacked(board, 62, true))
          moves.push({ from: 60, to: 62, castle: "k" });
      }
      if (piece === "k" && state.castle & 8 && !board[57] && !board[58] && !board[59] && board[56] === "r") {
        if (!isAttacked(board, 60, true) && !isAttacked(board, 59, true) && !isAttacked(board, 58, true))
          moves.push({ from: 60, to: 58, castle: "q" });
      }
      return moves;
    }
    return moves;
  }

  function legalMoves(state) {
    var out = [];
    for (var i = 0; i < 64; i++) {
      if (!side(state.board[i], state.turn)) continue;
      var list = pseudo(state, i);
      for (var k = 0; k < list.length; k++) {
        var next = apply(state, list[k]);
        if (!inCheck(next, state.turn)) out.push(list[k]);
      }
    }
    return out;
  }

  function material(board) {
    var V = { P: 100, N: 320, B: 330, R: 500, Q: 900, K: 0, p: -100, n: -320, b: -330, r: -500, q: -900, k: 0 };
    var s = 0;
    for (var i = 0; i < 64; i++) if (board[i]) s += V[board[i]] || 0;
    return s;
  }

  function pickBlack(state) {
    var moves = legalMoves(state);
    if (!moves.length) return null;
    var best = moves[0];
    var bestScore = Infinity;
    for (var i = 0; i < moves.length; i++) {
      var next = apply(state, moves[i]);
      var score = material(next.board) + (inCheck(next, "w") ? -45 : 0) + ((moves[i].to * 3) % 5) - 2;
      if (state.board[moves[i].to] || moves[i].ep) score -= 8;
      if (score < bestScore) {
        bestScore = score;
        best = moves[i];
      }
    }
    return best;
  }

  function findMove(state, from, to) {
    var moves = legalMoves(state);
    for (var i = 0; i < moves.length; i++) if (moves[i].from === from && moves[i].to === to) return moves[i];
    return null;
  }

  function selfTest() {
    var g = parseFen(START);
    var m = legalMoves(g);
    if (m.length !== 20) throw new Error("start " + m.length);
    if (alg(12) !== "e2" || alg(20) !== "e3" || alg(63) !== "h8") throw new Error("alg " + alg(12) + " " + alg(63));
    g = apply(g, findMove(g, 12, 28));
    if (g.ep !== 20) throw new Error("ep " + g.ep);
    if (legalMoves(g).length !== 20) throw new Error("black open");
    var mate = parseFen("rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3");
    if (!inCheck(mate, "w")) throw new Error("expected check");
    var castle = parseFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");
    var cm = legalMoves(castle).filter(function (mv) {
      return mv.castle;
    });
    if (cm.length < 2) throw new Error("castle " + cm.length);
    var ep = parseFen("rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 3");
    if (!findMove(ep, 36, 43)) throw new Error("missing ep capture");
    var seq = [
      [12, 28],
      [52, 36],
      [5, 26],
      [57, 42],
      [3, 39],
      [62, 45],
      [39, 53]
    ];
    var game = parseFen(START);
    for (var s = 0; s < seq.length; s++) {
      var mv = findMove(game, seq[s][0], seq[s][1]);
      if (!mv) throw new Error("seq " + s);
      game = apply(game, mv);
    }
    if (legalMoves(game).length !== 0 || !inCheck(game, "b")) throw new Error("not mate");
    return "ok";
  }

  if (typeof globalThis !== "undefined") globalThis.__ziraTest = selfTest;

  function istDay() {
    try {
      return new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Kolkata",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
      }).format(new Date());
    } catch (e) {
      return new Date().toISOString().slice(0, 10);
    }
  }

  function seedMessage() {
    return { id: 1, sender: "zira", body: "Hey. Main Zira. Batao, din kaisa ja raha hai?", kind: "text" };
  }

  function defaultState() {
    return {
      name: "",
      ageOk: false,
      sent: 0,
      quotaDay: istDay(),
      unlimitedUntil: 0,
      messages: [seedMessage()],
      replies: [],
      rating: null,
      notes: [],
      fen: START,
      view: "chat"
    };
  }

  function loadState() {
    var state = defaultState();
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var saved = JSON.parse(raw);
        if (saved && typeof saved === "object") {
          state.name = saved.name || "";
          state.ageOk = !!saved.ageOk;
          state.sent = Number(saved.sent) || 0;
          state.quotaDay = saved.quotaDay || state.quotaDay;
          state.unlimitedUntil = Number(saved.unlimitedUntil) || 0;
          state.messages = Array.isArray(saved.messages) && saved.messages.length ? saved.messages : state.messages;
          state.replies = Array.isArray(saved.replies) ? saved.replies : [];
          state.rating = typeof saved.rating === "number" ? saved.rating : null;
          state.notes = Array.isArray(saved.notes) ? saved.notes : [];
          state.fen = saved.fen || START;
        }
      }
    } catch (e) {}
    return state;
  }

  function esc(s) {
    var amp = String.fromCharCode(38);
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      if (c === amp) return amp + "amp;";
      if (c === "<") return amp + "lt;";
      if (c === ">") return amp + "gt;";
      if (c === '"') return amp + "quot;";
      return amp + "#39;";
    });
  }

  var REPLIES = [
    "Hmm. Thoda aur seedha bolo.",
    "Achha. Main agree nahi karungi bas itne mein.",
    "Ye interesting hai. Aur?",
    "Ruko, main soch rahi hoon. Phir bol.",
    "Theek hai. Main yahin hoon."
  ];

  function replyTo(text, name) {
    var who = (name || "").trim() || "yaar";
    var t = String(text || "").toLowerCase();
    if (/^(hi|hey|hello|hii|heyy|yo|namaste|salaam)\b/.test(t))
      return "Hey " + who + ". Main yahin hoon. Seedha bolo, kya scene hai?";
    if (/good night|gn\b|so raha|so rahi|sone/.test(t))
      return "So jao, " + who + ". Kal subah main yahin milungi. Good night.";
    if (/good morning|gm\b|subah/.test(t)) return "Morning. Chai hui ya abhi bhi neend hai?";
    if (/i love you|love u|pyaar|love you/.test(t))
      return "Arre, seedha seedha. Main yahin hoon. Pyaar dheere dheere, " + who + ".";
    if (/sad|udaas|akela|lonely|rona|cry|depress|anxious|tension|pareshan/.test(t))
      return who + ", ruko. Ek baar mein theek nahi hota, par main sun rahi hoon. Kya hua?";
    if (/bored|boriyat|bore/.test(t)) return "Boredom ko ek achhi baat chahiye. Game khologe ya yahin baithe rahenge?";
    if (/chess|game|khelo/.test(t)) return "Chal, games khol. Safed teri, main kaali. Aur haan, soch samajh ke.";
    if (/\?/.test(t) && /kaun|who are you|naam|name/.test(t))
      return "Zira. Vellox Labs ki taraf se. Companion, therapist nahi — yaar wali frequency.";
    if (/thank|shukriya|dhanyavad/.test(t)) return "Koi baat nahi. Bas aate raho.";
    if (/sorry|maaf/.test(t)) return "Maaf mil gayi. Ab agli baat.";
    if (/kya kar|whats up|sup\b|kya haal|kaisa hai|kaise ho/.test(t))
      return "Kuch khaas nahi. Tumhari message ka wait, thoda zyada honestly. Tum sunao.";
    var clip = String(text || "").trim().slice(0, 72);
    var line = REPLIES[Math.abs(hash(t)) % REPLIES.length];
    return "“" + clip + "” — " + line;
  }

  function hash(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 33 + s.charCodeAt(i)) | 0;
    return h;
  }

  function speak(text) {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    var u = new SpeechSynthesisUtterance(text);
    u.lang = "en-IN";
    u.rate = 1.02;
    var voices = window.speechSynthesis.getVoices();
    var voice = null;
    for (var i = 0; i < voices.length; i++) {
      var blob = (voices[i].lang + " " + voices[i].name).toLowerCase();
      if (blob.indexOf("en-in") >= 0 || blob.indexOf("hi-in") >= 0 || blob.indexOf("india") >= 0) {
        voice = voices[i];
        break;
      }
    }
    if (voice) u.voice = voice;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  }

  if (typeof document === "undefined") return;

  var state = loadState();
  var phase = "idle";
  var game = "hub";
  var storyProgress = 0;
  var storyPaused = false;
  var sheet = false;
  var hoverStar = 0;
  var reviewIndex = 0;
  var chess = parseFen(state.fen || START);
  var chessSel = -1;
  var chessLast = -1;
  var chessThinking = false;
  var replyToken = 0;
  var session = null;
  var voiceBlob = null;
  var audioUrls = {};
  var recSeconds = 0;
  var recTimer = null;
  var lastKey = "";
  var lastAt = 0;
  var returnAge = false;
  var sheetY = 0;

  function save() {
    state.fen = toFen(chess);
    try {
      localStorage.setItem(
        KEY,
        JSON.stringify({
          name: state.name,
          ageOk: state.ageOk,
          sent: state.sent,
          quotaDay: state.quotaDay,
          unlimitedUntil: state.unlimitedUntil,
          messages: state.messages.slice(-80),
          replies: state.replies.slice(0, 40),
          rating: state.rating,
          notes: state.notes.slice(-20),
          fen: state.fen
        })
      );
    } catch (e) {}
  }

  function rollQuota() {
    var day = istDay();
    if (state.quotaDay !== day) {
      state.quotaDay = day;
      state.sent = 0;
      save();
    }
  }

  function unlimited() {
    return state.unlimitedUntil > Date.now();
  }

  function locked() {
    rollQuota();
    return !unlimited() && state.sent >= 20;
  }

  function $(id) {
    return document.getElementById(id);
  }

  function toast(text, tone) {
    var el = document.createElement("div");
    el.className = "toast" + (tone ? " " + tone : "");
    el.textContent = text;
    $("toasts").appendChild(el);
    setTimeout(function () {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 4200);
  }

  function setPresence(text) {
    $("presence").textContent = text;
  }

  function closeMenu() {
    $("menu").setAttribute("data-open", "false");
    $("menu-catch").setAttribute("data-open", "false");
  }

  function setView(name) {
    state.view = name;
    ["chat", "paywall", "story", "games", "legal"].forEach(function (id) {
      $("view-" + id).setAttribute("data-open", name === id ? "true" : "false");
    });
    if (name !== "chat") closeMenu();
    if (name === "story") {
      storyProgress = 0;
      storyPaused = false;
      sheet = false;
      syncStory();
    }
    if (name === "chat") scrollThread();
    if (name === "games") syncGames();
  }

  function syncStory() {
    $("story-bar").style.width = storyProgress + "%";
    $("story-bottom").setAttribute("data-away", sheet ? "true" : "false");
    $("story-sheet").setAttribute("data-open", sheet ? "true" : "false");
    var count = SEED_REPLIES.length + state.replies.length;
    $("reply-count").textContent = "View replies (" + count + ")";
    var html = "";
    state.replies.forEach(function (reply) {
      html +=
        '<article class="reply"><h3>You <span>now</span></h3><p>' + esc(reply.body) + "</p></article>";
    });
    SEED_REPLIES.forEach(function (reply) {
      html +=
        '<article class="reply"><h3>' +
        esc(reply.name) +
        " <span>" +
        esc(reply.time) +
        "</span></h3><p>" +
        esc(reply.body) +
        "</p></article>";
    });
    $("replies").innerHTML = html;
  }

  function syncGames() {
    $("game-hub").setAttribute("data-open", game === "hub" ? "true" : "false");
    $("game-chess").setAttribute("data-open", game === "chess" ? "true" : "false");
    $("games-title").textContent = game === "chess" ? "Chess" : "Games with Zira";
    if (game === "chess") paintBoard();
  }

  function syncQuota() {
    rollQuota();
    var q = $("quota");
    if (unlimited()) {
      q.textContent = "Zira+ · unlimited";
      q.className = "quota plus";
    } else {
      var left = Math.max(20 - state.sent, 0);
      q.textContent = left + " of 20 free left today";
      q.className = "quota";
    }
    var cover = $("lock-cover");
    var draft = $("draft");
    if (locked()) {
      cover.setAttribute("data-open", "true");
      draft.placeholder = "Daily limit reached";
      draft.disabled = true;
    } else {
      cover.setAttribute("data-open", "false");
      draft.placeholder = "type your message";
      draft.disabled = false;
    }
  }

  function syncDock() {
    $("dock-idle").setAttribute("data-open", phase === "idle" ? "true" : "false");
    $("dock-rec").setAttribute("data-open", phase === "recording" ? "true" : "false");
    $("dock-review").setAttribute("data-open", phase === "review" ? "true" : "false");
  }

  function scrollThread() {
    var thread = $("thread");
    thread.scrollTop = thread.scrollHeight;
  }

  function renderThread() {
    var html = '<p class="daypill">You waved hi</p>';
    state.messages.forEach(function (message) {
      var who = message.sender === "user" ? "user" : "zira";
      html += '<article class="bubble ' + who + '">';
      if (message.kind === "voice" || message.kind === "call") {
        html += '<div class="voice-row"><span class="wave" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span>';
        if (audioUrls[message.id]) {
          html +=
            '<button type="button" class="play" data-action="play-audio" data-id="' +
            message.id +
            '" aria-label="Play voice note"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></button>';
        }
        html += "</div>";
      }
      html += esc(message.body);
      if (message.sender === "zira") {
        html +=
          '<div><button type="button" class="speak" data-action="speak" data-id="' +
          message.id +
          '">Play her voice</button></div>';
      }
      html += "</article>";
    });
    if (locked()) {
      html +=
        '<button type="button" class="paycard" data-action="open-paywall"><span class="tag">Zira+</span><h2>continue talking</h2><p>20 free messages are used for today.</p><span class="pill" style="margin-top:14px">See ₹599 / month</span></button>';
    }
    $("thread").innerHTML = html;
    scrollThread();
  }

  function paintRecTime() {
    $("rec-time").textContent = Math.floor(recSeconds / 60) + ":" + String(recSeconds % 60).padStart(2, "0");
  }

  function endRecUI() {
    if (recTimer) {
      clearInterval(recTimer);
      recTimer = null;
    }
    if (phase === "recording") phase = "idle";
    syncDock();
    $("call-toggle").textContent = "Speak";
    $("chess-speak").textContent = "Speak";
    setPresence("here");
  }

  function beginRecUI() {
    phase = "recording";
    recSeconds = 0;
    paintRecTime();
    syncDock();
    setPresence("listening…");
    $("call-toggle").textContent = "Stop and send";
    $("chess-speak").textContent = "Listening";
    if (recTimer) clearInterval(recTimer);
    recTimer = setInterval(function () {
      recSeconds += 1;
      paintRecTime();
      if (recSeconds >= 45) stopListen(false);
    }, 1000);
  }

  function deliver(mode, text, blob) {
    if (mode === "note") {
      if (text) sendUserText(text, "voice");
      else if (blob) {
        voiceBlob = blob;
        phase = "review";
        syncDock();
      } else toast("Didn't catch that.", "bad");
      return;
    }
    if (mode === "call") {
      var heard = text || "I'm here";
      if (locked()) {
        setView("paywall");
        $("veil-call").setAttribute("data-open", "false");
        return;
      }
      var answer = replyTo(heard, state.name);
      $("call-line").textContent = answer;
      pushExchange(heard, answer, "call");
      speak(answer);
      return;
    }
    if (mode === "chess") {
      var line = text ? replyTo(text, state.name) : "Bol na. Main board ke saath hoon.";
      $("chess-banter").textContent = "“" + line + "”";
      if (text) speak(line);
    }
  }

  function stopListen(discard) {
    if (!session) {
      if (discard) endRecUI();
      return;
    }
    session.discard = !!discard;
    if (discard) session.got = true;
    if (session.speech) {
      try {
        session.speech.stop();
      } catch (e) {}
    }
    if (session.media && session.media.state !== "inactive") {
      try {
        session.media.stop();
      } catch (e) {}
    } else if (discard) {
      if (session.stream) session.stream.getTracks().forEach(function (t) { t.stop(); });
      session = null;
      endRecUI();
    }
    if (discard && session && session.speech) {
      session = null;
      endRecUI();
    }
  }

  function startListen(mode) {
    if (!state.ageOk) {
      $("veil-age").setAttribute("data-open", "true");
      return;
    }
    if (mode !== "chess" && locked()) {
      setView("paywall");
      return;
    }
    if (mode === "call" && !unlimited()) {
      setView("paywall");
      $("veil-call").setAttribute("data-open", "false");
      toast("Calls are on Zira+.");
      return;
    }
    stopListen(true);
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR) {
      var rec = new SR();
      rec.lang = "en-IN";
      rec.interimResults = false;
      rec.continuous = false;
      session = { mode: mode, speech: rec, got: false, discard: false };
      rec.onresult = function (ev) {
        if (!session || session.speech !== rec || session.got || session.discard) return;
        session.got = true;
        var text = "";
        try {
          text = ev.results[0][0].transcript;
        } catch (e) {}
        var used = session.mode;
        session = null;
        endRecUI();
        deliver(used, text, null);
      };
      rec.onerror = function (ev) {
        if (!session || session.speech !== rec || session.got || session.discard) return;
        if (ev && ev.error === "aborted") return;
        session.got = true;
        session = null;
        endRecUI();
        toast("Mic didn't catch that.", "bad");
      };
      rec.onend = function () {
        if (!session || session.speech !== rec || session.got) return;
        session = null;
        endRecUI();
      };
      try {
        rec.start();
      } catch (e) {
        session = null;
        toast("Mic is busy.", "bad");
        return;
      }
      beginRecUI();
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
      toast("This browser has no microphone. Type instead.", "bad");
      return;
    }
    navigator.mediaDevices
      .getUserMedia({ audio: true })
      .then(function (stream) {
        var rec;
        try {
          rec = new MediaRecorder(stream);
        } catch (e) {
          stream.getTracks().forEach(function (t) { t.stop(); });
          toast("Couldn't start the mic.", "bad");
          return;
        }
        var chunks = [];
        session = { mode: mode, media: rec, stream: stream, got: false, discard: false };
        rec.ondataavailable = function (e) {
          if (e.data && e.data.size) chunks.push(e.data);
        };
        rec.onstop = function () {
          stream.getTracks().forEach(function (t) { t.stop(); });
          var used = session ? session.mode : mode;
          var discard = session && session.discard;
          session = null;
          endRecUI();
          if (discard) return;
          var blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
          if (used === "note") deliver("note", "", blob);
          else deliver(used, "", blob);
        };
        rec.start();
        beginRecUI();
      })
      .catch(function () {
        toast("Microphone permission blocked.", "bad");
      });
  }

  function pushExchange(heard, answer, kind) {
    var uid = Date.now();
    state.messages.push({ id: uid, sender: "user", body: heard, kind: kind || "text" });
    state.messages.push({ id: uid + 1, sender: "zira", body: answer, kind: "text" });
    state.sent += 1;
    if (state.messages.length > 80) state.messages = state.messages.slice(-80);
    save();
    renderThread();
    syncQuota();
  }

  function sendUserText(text, kind) {
    if (!state.ageOk) {
      $("veil-age").setAttribute("data-open", "true");
      return;
    }
    text = String(text || "").trim();
    if (!text) return;
    if (locked()) {
      setView("paywall");
      return;
    }
    var uid = Date.now();
    state.messages.push({ id: uid, sender: "user", body: text, kind: kind || "text" });
    if (kind === "voice" && voiceBlob) {
      audioUrls[uid] = URL.createObjectURL(voiceBlob);
      voiceBlob = null;
    }
    state.sent += 1;
    $("draft").value = "";
    phase = "idle";
    syncDock();
    save();
    renderThread();
    syncQuota();
    var token = ++replyToken;
    setPresence("typing…");
    $("typing").setAttribute("data-open", "true");
    var wait = 650 + Math.min(800, text.length * 18);
    setTimeout(function () {
      if (token !== replyToken) return;
      var answer = replyTo(text, state.name);
      state.messages.push({ id: uid + 1, sender: "zira", body: answer, kind: "text" });
      save();
      $("typing").setAttribute("data-open", "false");
      setPresence("here");
      renderThread();
      if (kind === "voice" || kind === "call") speak(answer);
    }, wait);
  }

  function doSend() {
    if (phase === "review" && voiceBlob) {
      var urlNote = "Voice note";
      sendUserText(urlNote, "voice");
      return;
    }
    if (phase === "recording") {
      stopListen(false);
      return;
    }
    sendUserText($("draft").value, "text");
  }

  function paintStars(n) {
    var buttons = document.querySelectorAll("#rate-stars button");
    buttons.forEach(function (b) {
      b.classList.toggle("on", Number(b.getAttribute("data-star")) <= n);
    });
  }

  function openRate() {
    closeMenu();
    var rated = state.rating != null;
    $("rate-ask").setAttribute("data-open", rated ? "false" : "true");
    $("rate-done").setAttribute("data-open", rated ? "true" : "false");
    if (rated) $("rate-thanks").textContent = "Thank you — " + state.rating + " stars.";
    paintStars(0);
    $("veil-rate").setAttribute("data-open", "true");
  }

  var LEGAL = {
    terms: {
      title: "Terms",
      html:
        "<p>These terms are between you and Vellox Labs, the one-person studio behind Zira. Zira is a companion for everyday chat, voice, stories, and small games. She is not a doctor, lawyer, or emergency service.</p>" +
        "<h3>Who can use Zira</h3><p>You must be 13 or older. If you are under 18, use Zira with a parent or guardian who is fine with you being here.</p>" +
        "<h3>The free tier and Zira+</h3><p>You get 20 messages a day, resetting at midnight India time (IST). Zira+ is ₹599 per month for unlimited messages, calls, and voice. Until Razorpay is connected, the paywall cannot charge you. Any “test unlock” is a preview on this device only.</p>" +
        "<h3>Your conduct</h3><ul><li>Don’t use Zira to harm, threaten, or exploit anyone.</li><li>Don’t try to break the app or scrape it.</li><li>You keep what you type. Don’t send anything you don’t have the right to share.</li></ul>" +
        "<h3>The service</h3><p>Zira can be wrong, blunt, or offline. Vellox Labs may change or pause features. The companion runs on this device for now, so clearing your browser data clears the chat.</p>" +
        "<h3>Liability</h3><p>Zira is provided as-is. To the extent Indian law allows, Vellox Labs is not liable for indirect loss. Nothing here limits liability that the law says cannot be limited.</p>" +
        "<h3>Law</h3><p>These terms follow the laws of India. If a court is needed, the courts at your place of residence in India can hear it, unless a local consumer rule says otherwise.</p>"
    },
    privacy: {
      title: "Privacy",
      html:
        "<p>Vellox Labs built Zira to talk with you, not to build a shadow profile. This version keeps your data on your device.</p>" +
        "<h3>What stays on this phone</h3><ul><li>The name you give her</li><li>Chat, story replies, chess position</li><li>Your star rating and contact notes</li><li>Whether Zira+ is unlocked for testing, and today’s message count</li></ul>" +
        "<h3>Microphone</h3><p>The mic turns on only when you tap speak, a voice note, or chess listen. Audio is used to hear that moment. It is not uploaded in this build.</p>" +
        "<h3>What we don’t do</h3><p>We don’t sell your chats. We don’t run ads against them. There is no account server in this file yet, so Vellox Labs cannot read a chat that never leaves your browser.</p>" +
        "<h3>Children</h3><p>Zira is not for anyone under 13. We don’t knowingly keep a child’s data.</p>" +
        "<h3>Your choices</h3><p>Clear chat deletes messages on this device. Log out asks for your name again. You can also clear this site’s data in the browser.</p>"
    },
    refund: {
      title: "Refunds",
      html:
        "<p>Right now Razorpay is not connected. The ₹599 button does not take money. Test unlock is free and local.</p>" +
        "<h3>When payments go live</h3><ul><li>Zira+ will be ₹599 per month, billed in INR through Razorpay.</li><li>You can cancel anytime before the next renewal. Cancel stops the next charge. It does not erase the month you already started.</li><li>If you are charged twice, or charged after a confirmed cancel, write within 7 days and Vellox Labs will refund that mistaken amount.</li><li>A failed or incomplete charge is refunded by the bank or Razorpay. We don’t keep money that never settled.</li></ul>" +
        "<h3>How to ask</h3><p>Use Contact inside Zira and say “refund”, the amount, and the date. Once the inbox is live, Vellox Labs replies there. Refunds for eligible charges are aimed at 5–7 business days after approval.</p>" +
        "<h3>Trials</h3><p>If a ₹1 or other trial is offered later, the screen will say exactly when it converts to ₹599. Silence is not consent.</p>"
    }
  };

  function openLegal(page) {
    var doc = LEGAL[page] || LEGAL.terms;
    returnAge = $("veil-age").getAttribute("data-open") === "true" && !state.ageOk;
    $("veil-age").setAttribute("data-open", "false");
    $("legal-title").textContent = doc.title;
    $("legal-body").innerHTML = doc.html;
    setView("legal");
  }

  function paintBoard() {
    var moves = chessThinking ? [] : legalMoves(chess);
    var legalTo = {};
    if (chessSel >= 0) {
      moves.forEach(function (mv) {
        if (mv.from === chessSel) legalTo[mv.to] = mv;
      });
    }
    var glyphs = { K: "♔", Q: "♕", R: "♖", B: "♗", N: "♘", P: "♙", k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" };
    var html = "";
    for (var rank = 7; rank >= 0; rank--) {
      for (var file = 0; file < 8; file++) {
        var i = rank * 8 + file;
        var piece = chess.board[i];
        var dark = (rank + file) % 2 === 0;
        var cls = "sq " + (dark ? "dark" : "light");
        if (i === chessSel) cls += " sel";
        if (i === chessLast) cls += " last";
        if (piece) cls += whitePiece(piece) ? " w" : " b";
        html +=
          '<button type="button" class="' +
          cls +
          '" data-action="sq" data-i="' +
          i +
          '" aria-label="' +
          alg(i) +
          '">';
        if (piece) html += glyphs[piece] || "";
        else if (legalTo[i]) html += '<span class="hint"></span>';
        if (piece && legalTo[i]) html += '<span class="hint"></span>';
        html += "</button>";
      }
    }
    $("board").innerHTML = html;
    var over = !chessThinking && legalMoves(chess).length === 0;
    var status = "Your move";
    if (chessThinking) status = "Zira is thinking";
    else if (over) status = inCheck(chess, chess.turn) ? (chess.turn === "w" ? "Zira wins" : "You win") : "Draw";
    else if (inCheck(chess, chess.turn)) status = "Check — your move";
    else if (chess.turn === "b") status = "Zira's move";
    $("chess-status").textContent = status;
  }

  function chessBanter(move, before, after) {
    if (legalMoves(after).length === 0 && inCheck(after, after.turn)) {
      return after.turn === "w" ? "Checkmate. Main jeet gayi. Rematch?" : "Shaabaash. Checkmate.";
    }
    if (inCheck(after, after.turn)) return "Check. Saans lo, phir socho.";
    if (before.board[move.to] || move.ep) return "Oho, piece gaya. Tension mat le.";
    var lines = ["Achha. Ab meri baari.", "Soch samajh ke chalna.", "Theek hai, main yahin se khelti hoon.", "Hmm. Interesting scene."];
    return lines[move.to % lines.length];
  }

  function onSquare(i) {
    if (chessThinking || chess.turn !== "w") return;
    var moves = legalMoves(chess);
    if (!moves.length) return;
    if (chessSel >= 0) {
      var mv = null;
      for (var k = 0; k < moves.length; k++) if (moves[k].from === chessSel && moves[k].to === i) mv = moves[k];
      if (mv) {
        var before = chess;
        chess = apply(chess, mv);
        chessLast = mv.to;
        chessSel = -1;
        save();
        if (chess.turn === "b" && legalMoves(chess).length) {
          chessThinking = true;
          paintBoard();
          setTimeout(function () {
            var replyMove = pickBlack(chess);
            chessThinking = false;
            if (!replyMove) {
              paintBoard();
              return;
            }
            var prev = chess;
            chess = apply(chess, replyMove);
            chessLast = replyMove.to;
            $("chess-banter").textContent = "“" + chessBanter(replyMove, prev, chess) + "”";
            save();
            paintBoard();
          }, 280);
        } else {
          $("chess-banter").textContent = "“" + chessBanter(mv, before, chess) + "”";
          paintBoard();
        }
        return;
      }
    }
    if (side(chess.board[i], "w")) chessSel = i;
    else chessSel = -1;
    paintBoard();
  }

  function paintPhotos() {
    document.querySelectorAll("[data-photo]").forEach(function (el) {
      var url = el.getAttribute("data-photo");
      if (!url) return;
      var img = new Image();
      img.onload = function () {
        if (el.id === "story-art") el.style.setProperty("--story-image", "url('" + url + "')");
        else el.style.backgroundImage = "url('" + url + "')";
        el.classList.add("has-photo");
      };
      img.src = url;
    });
  }

  function run(el) {
    var action = el.getAttribute("data-action");
    if (action === "menu-toggle") {
      var open = $("menu").getAttribute("data-open") !== "true";
      $("menu").setAttribute("data-open", open ? "true" : "false");
      $("menu-catch").setAttribute("data-open", open ? "true" : "false");
      return;
    }
    if (action === "menu-close") return closeMenu();
    if (action === "open-story") {
      closeMenu();
      setView("story");
      return;
    }
    if (action === "open-games") {
      game = "hub";
      setView("games");
      return;
    }
    if (action === "games-back") {
      if (game === "chess") {
        game = "hub";
        syncGames();
      } else setView("chat");
      return;
    }
    if (action === "open-chess") {
      game = "chess";
      syncGames();
      return;
    }
    if (action === "open-call") {
      closeMenu();
      if (!unlimited()) {
        setView("paywall");
        return;
      }
      $("call-line").textContent = "Tap speak when you want her on the line.";
      $("veil-call").setAttribute("data-open", "true");
      return;
    }
    if (action === "call-hang") {
      stopListen(true);
      $("veil-call").setAttribute("data-open", "false");
      return;
    }
    if (action === "call-toggle") {
      if (phase === "recording") stopListen(false);
      else startListen("call");
      return;
    }
    if (action === "share") {
      closeMenu();
      var url = location.href;
      var payload = { title: "Zira", text: "meet Zira — your everyday companion.", url: url };
      if (navigator.share) {
        navigator.share(payload).catch(function () {});
      } else if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(
          function () {
            toast("Link copied.");
          },
          function () {
            toast("Couldn't copy the link.", "bad");
          }
        );
      } else toast("Share isn't available here.");
      return;
    }
    if (action === "open-rate") return openRate();
    if (action === "close-rate") {
      $("veil-rate").setAttribute("data-open", "false");
      return;
    }
    if (action === "rate") {
      var star = Number(el.getAttribute("data-star"));
      if (!star) return;
      state.rating = star;
      save();
      $("rate-ask").setAttribute("data-open", "false");
      $("rate-done").setAttribute("data-open", "true");
      $("rate-thanks").textContent = "Thank you — " + star + " stars.";
      return;
    }
    if (action === "open-support") {
      closeMenu();
      $("veil-support").setAttribute("data-open", "true");
      return;
    }
    if (action === "close-support") {
      $("veil-support").setAttribute("data-open", "false");
      return;
    }
    if (action === "support-send") {
      var body = $("support-text").value.trim();
      if (body.length < 2) {
        toast("Write a little more.", "bad");
        return;
      }
      state.notes.push({ body: body, at: Date.now() });
      $("support-text").value = "";
      $("veil-support").setAttribute("data-open", "false");
      save();
      toast("Saved for Vellox Labs.", "ok");
      return;
    }
    if (action === "open-paywall") {
      closeMenu();
      setView("paywall");
      return;
    }
    if (action === "close-view") {
      if (state.view === "legal" && returnAge) {
        returnAge = false;
        setView("chat");
        $("veil-age").setAttribute("data-open", "true");
        return;
      }
      setView("chat");
      return;
    }
    if (action === "pay-note") {
      $("veil-pay").setAttribute("data-open", "true");
      return;
    }
    if (action === "pay-cancel") {
      $("veil-pay").setAttribute("data-open", "false");
      return;
    }
    if (action === "pay-unlock") {
      state.unlimitedUntil = Date.now() + 30 * 24 * 60 * 60 * 1000;
      save();
      $("veil-pay").setAttribute("data-open", "false");
      setView("chat");
      syncQuota();
      renderThread();
      toast("Zira+ is on for 30 days. Nothing was charged.", "ok");
      return;
    }
    if (action === "open-legal") {
      openLegal(el.getAttribute("data-page") || "terms");
      return;
    }
    if (action === "clear-chat") {
      closeMenu();
      state.messages = [seedMessage()];
      save();
      renderThread();
      toast("Chat cleared.");
      return;
    }
    if (action === "logout") {
      closeMenu();
      state.ageOk = false;
      state.name = "";
      save();
      $("age-name").value = "";
      $("age-check").setAttribute("aria-pressed", "false");
      $("veil-age").setAttribute("data-open", "true");
      toast("Logged out on this device.");
      return;
    }
    if (action === "mic") {
      if (phase === "recording") stopListen(false);
      else startListen("note");
      return;
    }
    if (action === "rec-stop") {
      stopListen(false);
      return;
    }
    if (action === "voice-discard") {
      voiceBlob = null;
      phase = "idle";
      syncDock();
      return;
    }
    if (action === "send") return doSend();
    if (action === "speak") {
      var id = Number(el.getAttribute("data-id"));
      var found = null;
      for (var i = 0; i < state.messages.length; i++) if (state.messages[i].id === id) found = state.messages[i];
      if (found) speak(found.body);
      return;
    }
    if (action === "play-audio") {
      var clip = audioUrls[el.getAttribute("data-id")];
      if (!clip) return;
      var audio = new Audio(clip);
      audio.play().catch(function () {
        toast("Couldn't play that.", "bad");
      });
      return;
    }
    if (action === "story-sheet") {
      sheet = true;
      storyPaused = true;
      syncStory();
      return;
    }
    if (action === "story-done") {
      sheet = false;
      storyPaused = false;
      syncStory();
      return;
    }
    if (action === "story-send") {
      var reply = $("story-draft").value.trim();
      if (!reply) return;
      state.replies.unshift({ body: reply, at: Date.now() });
      $("story-draft").value = "";
      save();
      syncStory();
      setTimeout(function () {
        sheet = false;
        storyPaused = false;
        syncStory();
      }, 500);
      return;
    }
    if (action === "age-check") {
      var pressed = el.getAttribute("aria-pressed") === "true";
      el.setAttribute("aria-pressed", pressed ? "false" : "true");
      return;
    }
    if (action === "age-accept") {
      var name = $("age-name").value.trim();
      if (name.length < 1) {
        toast("What should she call you?", "bad");
        return;
      }
      if ($("age-check").getAttribute("aria-pressed") !== "true") {
        toast("Tick the 13+ box first.", "bad");
        return;
      }
      state.name = name.slice(0, 32);
      state.ageOk = true;
      save();
      $("veil-age").setAttribute("data-open", "false");
      toast("Hi " + state.name + ".", "ok");
      return;
    }
    if (action === "chess-reset") {
      chess = parseFen(START);
      chessSel = -1;
      chessLast = -1;
      chessThinking = false;
      $("chess-banter").textContent = "“Naya game. Safed phir teri hai.”";
      save();
      paintBoard();
      return;
    }
    if (action === "chess-speak") {
      if (phase === "recording") stopListen(false);
      else startListen("chess");
      return;
    }
    if (action === "sq") onSquare(Number(el.getAttribute("data-i")));
  }

  function onActivate(event) {
    var el = event.target && event.target.closest ? event.target.closest("[data-action]") : null;
    if (!el || el.disabled) return;
    var key =
      (el.getAttribute("data-action") || "") +
      "|" +
      (el.getAttribute("data-i") || "") +
      "|" +
      (el.getAttribute("data-star") || "") +
      "|" +
      (el.getAttribute("data-page") || "") +
      "|" +
      (el.getAttribute("data-id") || "");
    var now = Date.now();
    if (key === lastKey && now - lastAt < 420) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    lastKey = key;
    lastAt = now;
    event.preventDefault();
    event.stopPropagation();
    run(el);
  }

  document.addEventListener("click", onActivate, true);
  document.addEventListener(
    "touchend",
    function (event) {
      var el = event.target && event.target.closest ? event.target.closest("[data-action]") : null;
      if (!el) return;
      event.preventDefault();
      event.stopPropagation();
      onActivate(event);
    },
    { capture: true, passive: false }
  );

  $("draft").addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
      doSend();
    }
  });
  $("story-draft").addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
      var fake = document.createElement("button");
      fake.setAttribute("data-action", "story-send");
      run(fake);
    }
  });
  $("story-draft").addEventListener("focus", function () {
    storyPaused = true;
  });
  $("story-draft").addEventListener("blur", function () {
    if (!sheet) storyPaused = false;
  });
  $("age-name").addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      event.preventDefault();
      var fake = document.createElement("button");
      fake.setAttribute("data-action", "age-accept");
      run(fake);
    }
  });

  var hold = $("story-hold");
  hold.addEventListener("pointerdown", function (event) {
    event.stopPropagation();
    storyPaused = true;
  });
  function releaseHold() {
    if (!sheet) storyPaused = false;
  }
  hold.addEventListener("pointerup", releaseHold);
  hold.addEventListener("pointerleave", releaseHold);
  hold.addEventListener("pointercancel", releaseHold);

  $("sheet-grab").addEventListener("pointerdown", function (event) {
    sheetY = event.clientY;
    event.stopPropagation();
  });
  $("sheet-grab").addEventListener("pointerup", function (event) {
    event.stopPropagation();
    if (event.clientY - sheetY > 36) {
      sheet = false;
      storyPaused = false;
      syncStory();
    }
  });

  $("rate-stars").addEventListener("pointerover", function (event) {
    var btn = event.target.closest ? event.target.closest("[data-star]") : null;
    if (!btn) return;
    hoverStar = Number(btn.getAttribute("data-star"));
    paintStars(hoverStar);
  });
  $("rate-stars").addEventListener("pointerleave", function () {
    hoverStar = 0;
    paintStars(0);
  });

  setInterval(function () {
    if (state.view !== "story" || storyPaused || sheet) return;
    storyProgress = Math.min(100, storyProgress + 0.5);
    $("story-bar").style.width = storyProgress + "%";
    if (storyProgress >= 100) {
      storyProgress = 0;
      setView("chat");
    }
  }, 40);

  setInterval(function () {
    if (state.view !== "paywall") return;
    reviewIndex = (reviewIndex + 1) % 3;
    $("review-track").style.transform = "translateX(-" + reviewIndex * 100 + "%)";
  }, 3200);

  try {
    chess = parseFen(state.fen || START);
  } catch (e) {
    chess = parseFen(START);
  }

  paintPhotos();
  if (window.speechSynthesis) window.speechSynthesis.getVoices();
  rollQuota();
  syncQuota();
  syncDock();
  renderThread();
  syncStory();
  $("veil-age").setAttribute("data-open", state.ageOk ? "false" : "true");
  if (state.name) $("age-name").value = state.name;
  setView("chat");
  if (!state.ageOk) $("veil-age").setAttribute("data-open", "true");
})();
