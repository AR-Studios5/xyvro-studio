//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bu36Ki5b.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/legal/$page",
			"/api/auth/$"
		],
		preloads: ["/assets/index-Cd760cKJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cd760cKJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B-RnJOAO.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-DUlD7exD.js", "/assets/phone-2OL7pyVs.js"]
	},
	"/legal/$page": {
		filePath: "/workspace/src/routes/legal.$page.tsx",
		children: void 0,
		preloads: ["/assets/legal._page-TiyNX6kh.js", "/assets/phone-2OL7pyVs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
