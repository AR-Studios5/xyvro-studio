import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <main className="fixed inset-0 bg-[#F3EDE4]">
      <h1 className="sr-only">Zira, your everyday companion from Vellox Labs.</h1>
      <iframe
        title="Zira"
        src="/zira-app/index.html"
        allow="microphone; clipboard-write"
        className="absolute inset-0 h-full w-full border-0 bg-[#F3EDE4]"
      />
    </main>
  );
}
